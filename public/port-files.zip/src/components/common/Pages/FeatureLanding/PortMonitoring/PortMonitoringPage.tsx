import PortMonitoringHero from './PortMonitoringHero';

export default function PortMonitoringPage() {
  return (
    <div>
      <PortMonitoringHero />
    </div>
  );
}
